<?php

session_start();

include("ayar.php");



if ($_SESSION["giris"] != sha1(md5("var")) || $_COOKIE["kullanici"] != "msb") {

    //header("Location: cikis.php");

}



$id = $_GET['id'];







$sql = "delete from ozet where 'isim' and 'ozet'='id'";

//$sil=$baglan->query($sql);



if($baglan->query($sql)===TRUE)

  {

    echo"<script>alert('silindi.')</script>";

    header('Location: sairekle.php');

  }
else{
	echo"<script>alert('silinmedi.')</script>";
}







?>