<?php
    session_start();
    include("ayar.php");
    $sonuc= $baglan->query("select * from sairekle where id='$id'");
    if ($sonuc->num_rows > 0) 
    {
    while($cek = $sonuc->fetch_assoc()) 
    {
    $tur=$cek["tur"];
    }
    } 


?>
<!doctype html>
<html>
    <head><meta charset="utf-8">
    <title>LAVİNİA</title>
    <meta content="width=device-width, initial-scale=1.0" name="viewport">
    <meta content="Free HTML Templates" name="keywords">
    <meta content="Free HTML Templates" name="description">

    <!-- Favicon -->
    
    <!-- Google Web Fonts -->
    <link rel="preconnect" href="https://fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css2?family=Roboto+Condensed:wght@400;700&family=Roboto:wght@400;700&display=swap" rel="stylesheet">  

    <!-- Icon Font Stylesheet -->
    
    <!-- Libraries Stylesheet -->
    <link href="lib/owlcarousel/assets/owl.carousel.min.css" rel="stylesheet">
    <link href="lib/tempusdominus/css/tempusdominus-bootstrap-4.min.css" rel="stylesheet" />

    <!-- Customized Bootstrap Stylesheet -->
    <link href="css/bootstrap.min.css" rel="stylesheet">

    <!-- Template Stylesheet -->
    <link href="css/style.css" rel="stylesheet">
    </head>
    <body>

     <!-- Navbar Start -->
    <div class="container-fluid sticky-top bg-white shadow-sm">
        <div class="container">
            <nav class="navbar navbar-expand-lg bg-white navbar-light py-3 py-lg-0">
                <a href="index.php" class="navbar-brand">
                    <h1 class="m-0 text-uppercase text-primary"><i class="fa fa-clinic-medical me-2" ></i>Lavinia</h1>
                   <!-- <img class="img-fluid rounded-circle mx-auto" src="img/lavinia-1.jpg" alt="">-->
                </a>
                <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarCollapse">
                    <span class="navbar-toggler-icon"></span>
                </button>
                <div class="collapse navbar-collapse" id="navbarCollapse">
                    <div class="navbar-nav ms-auto py-0">
                        <a href="index.php" class="nav-item nav-link active">Anasayfa</a>
                        <a href="Hakkimizda.php" class="nav-item nav-link">Hakkımızda</a>
                        <a href="Turk.php" class="nav-item nav-link">Türk Şairler</a>
                        <a href="Yabanci.php" class="nav-item nav-link">Yabancı Şairler</a>
                        <a href="Iletisim.php" class="nav-item nav-link">İletişim</a>
            
                    </div>
                </div>
            </nav>
        </div>
    </div>
    <!-- Navbar End -->


    <!-- Hero Start -->
    <div class="container-fluid p-0 mb-5 wow fadeIn" data-wow-delay="0.1s">
        <div id="header-carousel" class="carousel slide" data-bs-ride="carousel">
            <div class="carousel-inner">
                <div class="carousel-item active">
                    <img class="w-100" src="img/hero.jpeg" alt="Image">
                    <div class="carousel-caption d-flex align-items-center justify-content-center text-start">
                        <div class="mx-sm-5 px-5" style="max-width: 900px;">
                           <center> <h1 class="display-2 text-white text-uppercase mb-4 animated slideInDown">Bir kitap, her okudugunuzda size yeni bir seyler sunar.</h1></center> 
</div>
</div>
</div>
</div>
</div>
</div>
                   
    

    <!-- Hero End -->

    <!-- Blog Start -->
    <div class="container-fluid py-5">
        <div class="container">
            <div class="text-center mx-auto mb-5" style="max-width: 500px;">
                <h5 class="d-inline-block text-primary text-uppercase border-bottom border-5">Blog Yazılarımız</h5>
                <h1 class="display-4">Şairlerle ilgili son bloglarımız</h1>
            </div>

            
				
				<?php
				include("ayar.php");
				$sonuc= $baglan->query("select * from sairekle ");
				
				if ($sonuc->num_rows > 0) 
				{
					while($cek = $sonuc->fetch_assoc()) 
					{
						$id=$cek["id"];
						$isim=$cek["isim"];
						$aciklama=$cek["aciklama"];
						$ozet=$cek["ozet"];
						echo "<div class='row g-5'>
						<div class='col-xl-4 col-lg-6'>
                    <div class='bg-light rounded overflow-hidden'>
                        <img class='img-fluid w-100' src='img/blog1.jpg' alt=''>

                        <div class='p-4'>
 				
                            <a class='h3 d-block mb-3' href='detay.php?id='".$id." class='nav-item nav-link'>".$isim."</a>
							<p class='m-0'>".$aciklama."</p>
							                        </div>
							<div class='d-flex justify-content-between border-top p-4'>
                            <div class='d-flex align-items-center'>
                                <img class='rounded-circle me-2' src='img/userr.jpg' width='25' height='25' alt=''>
                                <small>lavinia</small>
                            </div>
                        </div>
						</div>" ;
					}
				} 
				?>
				


                    
                </div>  
			
            </div>
        </div>
    </div>
    <!-- Blog End -->
    


    <!-- Testimonial Start -->
    <div class="container-fluid py-5">
        <div class="container">
            <div class="text-center mx-auto mb-5" style="max-width: 500px;">
                <h5 class="d-inline-block text-primary text-uppercase border-bottom border-5">Blog Yazarları</h5>
                <h1 class="display-4">Yazarlarımız Anlatıyor</h1>
            </div>
            <div class="row justify-content-center">
                <div class="col-lg-8">
                    <div class="owl-carousel testimonial-carousel">
                        <div class="testimonial-item text-center">
                            <div class="position-relative mb-5">
                                <center><img class="img-fluid rounded-circle mx-auto" src="img/batuhan.jpg" alt=""></center>
                            </div>
                            <p class="fs-4 fw-normal">Dolores sed duo clita tempor justo dolor et stet lorem kasd labore dolore lorem ipsum. At lorem lorem magna ut et, nonumy et labore et tempor diam tempor erat. Erat dolor rebum sit ipsum.</p>
                            <hr class="w-25 mx-auto">
                            <h3>Batuhan Toruk</h3>
                            
                        </div>
                        <div class="testimonial-item text-center">
                            <div class="position-relative mb-5">
                                <center><img class="img-fluid rounded-circle mx-auto" src="img/taha.jpg" alt=""></center>
                            </div>
                            <p class="fs-4 fw-normal">Dolores sed duo clita tempor justo dolor et stet lorem kasd labore dolore lorem ipsum. At lorem lorem magna ut et, nonumy et labore et tempor diam tempor erat. Erat dolor rebum sit ipsum.</p>
                            <hr class="w-25 mx-auto">
                            <h3>Taha Fere</h3>
                            
                        </div>
                        <div class="testimonial-item text-center">
                            <div class="position-relative mb-5">
                                <center><img class="img-fluid rounded-circle mx-auto" src="img/denizz.jpg" alt=""></center>
                            </div>
                            <p class="fs-4 fw-normal">Dolores sed duo clita tempor justo dolor et stet lorem kasd labore dolore lorem ipsum. At lorem lorem magna ut et, nonumy et labore et tempor diam tempor erat. Erat dolor rebum sit ipsum.</p>
                            <hr class="w-25 mx-auto">
                            <h3>Deniz Yıldız</h3>
                            
                        </div>
                        <div class="testimonial-item text-center">
                            <div class="position-relative mb-5">
                                <center><img class="img-fluid rounded-circle mx-auto" src="img/fatmanur.jpg" alt=""></center>
                            </div>
                            <p class="fs-4 fw-normal">Dolores sed duo clita tempor justo dolor et stet lorem kasd labore dolore lorem ipsum. At lorem lorem magna ut et, nonumy et labore et tempor diam tempor erat. Erat dolor rebum sit ipsum.</p>
                            <hr class="w-25 mx-auto">
                            <h3>Fatma Nur Tilaver</h3>
                            
                        </div>
                        <div class="testimonial-item text-center">
                            <div class="position-relative mb-5">
                                <center><img class="img-fluid rounded-circle mx-auto" src="img/tuna.jpg" alt=""></center>
                            </div>
                            <p class="fs-4 fw-normal">Dolores sed duo clita tempor justo dolor et stet lorem kasd labore dolore lorem ipsum. At lorem lorem magna ut et, nonumy et labore et tempor diam tempor erat. Erat dolor rebum sit ipsum.</p>
                            <hr class="w-25 mx-auto">
                            <h3>Tuna Kaynar</h3>
                        
                        </div>
                        <div class="testimonial-item text-center">
                            <div class="position-relative mb-5">
                                <center><img class="img-fluid rounded-circle mx-auto" src="img/sila.jpg" alt=""></center>
                            </div>
                            <p class="fs-4 fw-normal">Dolores sed duo clita tempor justo dolor et stet lorem kasd labore dolore lorem ipsum. At lorem lorem magna ut et, nonumy et labore et tempor diam tempor erat. Erat dolor rebum sit ipsum.</p>
                            <hr class="w-25 mx-auto">
                            <h3>Sıla Nur Perktaş</h3>
                            
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Testimonial End -->


    

    <!-- Footer Start -->
    <div class="container-fluid bg-dark text-light mt-5 py-5">
        <div class="container py-5">
            <div class="row g-5">
                <div class="col-lg-3 col-md-6">
                    <h4 class="d-inline-block text-primary text-uppercase border-bottom border-5 border-secondary mb-4">İletişim</h4>
                    <p class="mb-4">Sorunlarınız,Şikayetleriniz ve önerileriniz için bize ulaşın</p>
                    <p class="mb-2"><i class="fa fa-map-marker-alt text-primary me-3"></i>Gönen Meslek YüksekOkulu/Gönen</p>
                    <p class="mb-2"><i class="fa fa-envelope text-primary me-3"></i>info@example.com</p>
                    <p class="mb-0"><i class="fa fa-phone-alt text-primary me-3"></i>+9005363333333</p>
                </div>
                <div class="col-lg-3 col-md-6">
                    <h4 class="d-inline-block text-primary text-uppercase border-bottom border-5 border-secondary mb-4">Sayfalar</h4>
                    <div class="d-flex flex-column justify-content-start">
                        <a class="text-light mb-2" href="index.php"><i class="fa fa-angle-right me-2"></i>Anasayfa</a>
                        <a class="text-light mb-2" href="Hakkimizda.php"><i class="fa fa-angle-right me-2"></i>Hakkımızda</a>
                        <a class="text-light mb-2" href="Turk.php"><i class="fa fa-angle-right me-2"></i>Türk Şairler</a>
                        <a class="text-light mb-2" href="Yabanci.php"><i class="fa fa-angle-right me-2"></i>Yabancı Şairler</a>
                        <a class="text-light mb-2" href="Iletisim.php"><i class="fa fa-angle-right me-2"></i>İletişim</a>
                    </div>
                </div>
                
                <div class="col-lg-3 col-md-6">
                    <h4 class="d-inline-block text-primary text-uppercase border-bottom border-5 border-secondary mb-4">Takipte Kalın</h4>
                    <form action="">
                        <div class="input-group">
                            <input type="text" class="form-control p-3 border-0" placeholder="Email adresiniz">
                            <button class="btn btn-primary"> Gönder</button>
                        </div>
                    </form>
                    
                </div>
            </div>
        </div>
    </div>
    <div class="container-fluid bg-dark text-light border-top border-secondary py-4">
        <div class="container">
            <div class="row g-5">
                <div class="col-md-6 text-center text-md-start">
                    <p class="mb-md-0">&copy; <a class="text-primary" href="#">Lavinia</a>. Tüm haklar saklıdır.</p>
                </div>
                <div class="col-md-6 text-center text-md-end">
                    <p class="mb-0">Designed by <a class="text-primary" href="https://htmlcodex.com">HTML Codex</a></p>
                </div>
            </div>
        </div>
    </div>
    <!-- Footer End -->


    <!-- Back to Top -->
    <a href="#" class="btn btn-lg btn-primary btn-lg-square back-to-top"><i class="bi bi-arrow-up"></i></a>


    <!-- JavaScript Libraries -->
    <script src="https://code.jquery.com/jquery-3.4.1.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="lib/easing/easing.min.js"></script>
    <script src="lib/waypoints/waypoints.min.js"></script>
    <script src="lib/owlcarousel/owl.carousel.min.js"></script>
    <script src="lib/tempusdominus/js/moment.min.js"></script>
    <script src="lib/tempusdominus/js/moment-timezone.min.js"></script>
    <script src="lib/tempusdominus/js/tempusdominus-bootstrap-4.min.js"></script>

    <!-- Template Javascript -->
    <script src="js/main.js"></script>


      

    </body>
</html>