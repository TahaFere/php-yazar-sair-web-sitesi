<?php

    $baglan = new mysqli("localhost","tasarli2_ip211","z0HS7MggIbBh","tasarli2_ip211");
    $baglan->set_charset("utf8");

?>